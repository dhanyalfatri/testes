#Aplikasi E-Commerce Penjualan Spare Part Komputer (PHP, MySQL, CMS Toko Lokomedia)
Login pengguna:

Administrator:

    Username: admin
    Password: admin

Semoga bermanfaat.