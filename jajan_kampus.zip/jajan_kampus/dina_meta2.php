<?php
		echo "jajan kampus, makanan minuman , toko online";
?>
